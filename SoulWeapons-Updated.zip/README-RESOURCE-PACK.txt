# SoulWeapons 32x32 Resource Pack (Java 1.21.11)

## Included
- Five transparent 32x32 pixel-art weapon textures.
- Minecraft 1.21.11 item model definitions.
- Updated SoulWeapons source: each weapon assigns its matching `soulweapons:<weapon_id>` item model.

## Build the updated plugin
Build this project with Java 21 and Maven:
`mvn clean package`
The JAR will be in `target/`.

## Install the resource pack
1. Zip the CONTENTS of the `resource-pack` folder (pack.mcmeta must be at the ZIP root).
2. Upload that ZIP to a direct-download HTTPS host.
3. Put the direct ZIP URL in your server `server.properties` as `resource-pack=YOUR_URL`.
4. Restart the server and accept the pack in Minecraft Java.
5. Replace the old SoulWeapons JAR with the newly built JAR and restart.

Important: The resource pack is for Minecraft Java 1.21.11. The client must accept/use the pack. The updated plugin and pack must be used together; the old JAR does not assign the custom item models.
